package cinema.model;

public class Usuario {

    // Demais atributos, construtores e métodos da classe...

    public double calcularValorBilhete(double valor) {
        return valor;
    }
}